import csv

with open("./SPSS_原始数据.csv", newline='') as f:
    f_csv = csv.DictReader(f)
    with open("./SPSS_处理数据.csv", "w+", newline='') as r:
        r_csv = csv.DictWriter(r, fieldnames=(
            'Location', 'Year', 'Sex', 'Age', 'Paternity', 
            'Motherhood', 'Father Living', 'Mother Living', 
            'Other Ralatives', 'Num of Living Together', 'Capacity', 
            'Num of Disease(Himself)', 'Type of Disease(Himself)', 
            'Num of Disease(His Family)', 'Type of Disease(His Family)', 
            'Grade', 'Record', 
            'Farming', 'Working', 'Funded', 'Allowance', 'Scavenging'
            ))
        r_csv.writeheader()
        for row in f_csv:
            result:dict = {}

            bianhao = row['编号']
            if bianhao[:2] == 'EZ':
                result['Location'] = '2'
            elif bianhao[:2] == 'SZ':
                result['Location'] = '3'
            elif bianhao[:2] == 'JZ':
                result['Location'] = '1'
            else:
                raise TypeError
            result['Year'] = '20'+bianhao[2:4]

            result['Age'] = row['年龄']

            if row['性别'] == '女':
                result['Sex'] = 0
            else:
                result['Sex'] = 1

            if row['家庭结构'] == '0':
                result['Paternity'] = 1
                result['Motherhood'] = 1
                result['Father Living'] = 1
                result['Mother Living'] = 1
                result['Other Ralatives'] = -1
            elif row['家庭结构'] == '1':
                result['Paternity'] = 0
                result['Motherhood'] = 1
                result['Father Living'] = -1
                result['Mother Living'] = 1
                result['Other Ralatives'] = -1
            elif row['家庭结构'] == '2':
                result['Paternity'] = 1
                result['Motherhood'] = 0
                result['Father Living'] = 1
                result['Mother Living'] = -1
                result['Other Ralatives'] = -1
            elif row['家庭结构'] == '3':
                result['Paternity'] = 0
                result['Motherhood'] = 1
                result['Father Living'] = 0
                result['Mother Living'] = 1
                result['Other Ralatives'] = -1
            elif row['家庭结构'] == '4':
                result['Paternity'] = 1
                result['Motherhood'] = 0
                result['Father Living'] = 1
                result['Mother Living'] = 0
                result['Other Ralatives'] = -1
            elif row['家庭结构'] == '5':
                result['Paternity'] = 0
                result['Motherhood'] = 0
                result['Father Living'] = -1
                result['Mother Living'] = -1
                result['Other Ralatives'] = 1
            else:
                raise TypeError
            
            if row['劳动能力'] == '普通劳动力':
                result['Capacity'] = 3
            elif row['劳动能力'] == '弱劳动力':
                result['Capacity'] = 2
            elif row['劳动能力'] == '无劳动力':
                result['Capacity'] = 1
            else:
                raise TypeError

            result['Num of Living Together'] = row['共同生活人口数']

            if len(row['本人疾病数量']):
                result['Num of Disease(Himself)'] = row['本人疾病数量']
            else:
                result['Num of Disease(Himself)'] = 0

            if row['本人疾病分类'] == '大病':
                result['Type of Disease(Himself)'] = 1
            elif row['本人疾病分类'] == '慢病':
                result['Type of Disease(Himself)'] = 2
            elif row['本人疾病分类'] == '常见多发病':
                result['Type of Disease(Himself)'] = 3
            else:
                result['Type of Disease(Himself)'] = 4

            if len(row['家庭成员疾病数量']):
                result['Num of Disease(His Family)'] = row['家庭成员疾病数量']
            else:
                result['Num of Disease(His Family)'] = 0

            if row['家庭成员疾病分类'] == '大病':
                result['Type of Disease(His Family)'] = 1
            elif row['家庭成员疾病分类'] == '慢病':
                result['Type of Disease(His Family)'] = 2
            elif row['家庭成员疾病分类'] == '常见多发病':
                result['Type of Disease(His Family)'] = 3
            else:
                result['Type of Disease(His Family)'] = 4

            if row['学习阶段'] == '初中一年级':
                result['Grade'] = 1
            elif row['学习阶段'] == '初中二年级':
                result['Grade'] = 2
            
            if row['学习情况'] == '优异':
                result['Record'] = 5
            elif row['学习情况'] == '较好':
                result['Record'] = 4
            elif row['学习情况'] == '中等':
                result['Record'] = 3
            elif row['学习情况'] == '较差':
                result['Record'] = 2
            elif row['学习情况'] == '很差':
                result['Record'] = 1
            else:
                result['Record'] = 0

            if row['家庭收入来源'].count('务农'):
                result['Farming'] = 1
            else:
                result['Farming'] = 0
            if row['家庭收入来源'].count('打工'):
                result['Working'] = 1
            else:
                result['Working'] = 0
            if row['家庭收入来源'].count('亲戚资助'):
                result['Funded'] = 1
            else:
                result['Funded'] = 0
            if row['家庭收入来源'].count('拾荒'):
                result['Scavenging'] = 1
            else:
                result['Scavenging'] = 0
            if row['家庭收入来源'].count('低保'):
                result['Allowance'] = 1
            else:
                result['Allowance'] = 0

            r_csv.writerow(result)

        